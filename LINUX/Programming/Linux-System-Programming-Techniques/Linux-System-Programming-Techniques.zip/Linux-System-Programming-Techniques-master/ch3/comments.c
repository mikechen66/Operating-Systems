#include <stdio.h>

int main(void)
{
    // A C99 comment
    printf("hello, world\n");
    return 0;
}