#include <stdio.h>

int main(void)
{
    fputs("hello, world\n", stdout);
    return 0;
}