void printHelp(FILE *stream, char progname[]);
int circle(void);
int rectangle(void);
int triangle(void);
