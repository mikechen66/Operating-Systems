int cube(int n)
{
    return n*n*n;
}
