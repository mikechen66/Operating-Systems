int cube(int n);
