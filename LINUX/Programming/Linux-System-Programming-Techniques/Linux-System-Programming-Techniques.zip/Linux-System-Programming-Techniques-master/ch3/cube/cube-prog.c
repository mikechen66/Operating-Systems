#include "cube.h"
#define NUMBER 4

int main(void)
{
    return cube(NUMBER);
}
