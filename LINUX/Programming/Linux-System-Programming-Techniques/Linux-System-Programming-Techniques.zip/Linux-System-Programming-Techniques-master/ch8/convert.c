float c_to_f(float celsius)
{
    return (celsius*9/5+32);
}

float c_to_k(float celsius)
{
    return (celsius + 273.15);
}
