float c_to_f(float celsius);
float c_to_k(float celsius);
