typedef	unsigned short comp_t;
	/* "floating point": 3 bits base 8 exp, 13-bits fraction */

struct	acct
{
	char	ac_comm[10];		/* command name */
	comp_t	ac_utime;		/* user time */
	comp_t	ac_stime;		/* system time */
	comp_t	ac_etime;		/* elapsed time */
	time_t	ac_btime;		/* beginning time */
	short	ac_uid;			/* user ID */
	short	ac_gid;			/* group ID */
	short	ac_mem;			/* average memory usage */
	comp_t	ac_io;			/* number of disk IO blocks */
	dev_t	ac_tty;			/* control typewriter */
	comp_t	ac_rw;			/* blocks read or written */
	char	ac_flag;		/* accounting flag */
};	
	/* flag bits */
#define	AFORK	01		/* has executed fork, but no exec */
#define	ASU	02		/* used super-user privileges */
